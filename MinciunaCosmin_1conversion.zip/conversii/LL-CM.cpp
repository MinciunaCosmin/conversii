#include<fstream>
#include<iostream>
using namespace std;

int a[100][100],n;

int main()
{int x,y;

    fstream f;
    f.open("input_f.dat",ios::in);
    f>>n;

    fstream g;
    g.open("output_f.dat",ios::out);
    g<<n<<endl;
    g<<n+1<<endl;

    for(int i=0;i<n;i++)
    {
        f>>x;
        for(int j=0;j<n-1;j++)
        {f>>y;
        if(y) {
                a[i][y-1]=1;
        if(i<y-1)
            g<<i+1<<" "<<y<<endl;}}
    }

    f.close();
    g.close();
}
