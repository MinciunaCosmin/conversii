#include<fstream>
#include<iostream>
using namespace std;

int main()
{ int n,a[100][100];
    fstream f;
    f.open("input_f.dat",ios::in);
    f>>n;
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
        f>>a[i][j];


    fstream g;
    g.open("output_f.dat",ios::out);
    g<<n<<endl;
    g<<n+1<<endl;
    for(int i=0;i<n;i++)
    {for(int j=0;j<n;j++)
        if(a[i][j]==1 && i<j) {g<<i+1<<" "<<j+1;
        g<<endl;}}

    f.close();
    g.close();
}
